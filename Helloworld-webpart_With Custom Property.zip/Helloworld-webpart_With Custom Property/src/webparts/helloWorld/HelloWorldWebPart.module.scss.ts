/* tslint:disable */
require("./HelloWorldWebPart.module.css");
const styles = {
  helloWorld: 'helloWorld_7ec12a38',
  container: 'container_7ec12a38',
  row: 'row_7ec12a38',
  column: 'column_7ec12a38',
  'ms-Grid': 'ms-Grid_7ec12a38',
  title: 'title_7ec12a38',
  subTitle: 'subTitle_7ec12a38',
  description: 'description_7ec12a38',
  button: 'button_7ec12a38',
  label: 'label_7ec12a38'
};

export default styles;
/* tslint:enable */